import React from 'react';
import './Heading.css'

const Heading = () => {
    return (
        <div className="Heading">
            <h1>Upcoming movies!</h1>
        </div>
    )
}

export default Heading;