self.__precacheManifest = [
  {
    "revision": "fa3b4258b78fc8be40b1",
    "url": "/projects/projects2018/react-movie-api/static/css/main.90c6a828.chunk.css"
  },
  {
    "revision": "fa3b4258b78fc8be40b1",
    "url": "/projects/projects2018/react-movie-api/static/js/main.fa3b4258.chunk.js"
  },
  {
    "revision": "6221052083d9d7c06dcf",
    "url": "/projects/projects2018/react-movie-api/static/js/1.62210520.chunk.js"
  },
  {
    "revision": "b03b6aca44fc24c83843",
    "url": "/projects/projects2018/react-movie-api/static/js/runtime~main.b03b6aca.js"
  },
  {
    "revision": "6006926649521eb9fabb2c5914a3535c",
    "url": "/projects/projects2018/react-movie-api/index.html"
  }
];