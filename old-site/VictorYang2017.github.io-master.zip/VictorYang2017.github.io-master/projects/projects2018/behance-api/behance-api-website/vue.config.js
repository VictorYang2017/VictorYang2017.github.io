module.exports = {
    baseUrl: "/projects/projects2018/behance-api/"
}