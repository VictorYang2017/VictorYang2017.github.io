self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "875de271dbee1d9e745cdf7ff63c3c6a",
    "url": "/projects/projects2018/--testing-temp--/index.html"
  },
  {
    "revision": "3a3ea32a3b84e77c69d4",
    "url": "/projects/projects2018/--testing-temp--/static/css/main.f7c62102.chunk.css"
  },
  {
    "revision": "e9721ba3fe1135e0d8e7",
    "url": "/projects/projects2018/--testing-temp--/static/js/2.ff24a8b3.chunk.js"
  },
  {
    "revision": "067c720f316f6144a1c66a8687f10ed7",
    "url": "/projects/projects2018/--testing-temp--/static/js/2.ff24a8b3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3a3ea32a3b84e77c69d4",
    "url": "/projects/projects2018/--testing-temp--/static/js/main.84c02ea8.chunk.js"
  },
  {
    "revision": "8172c18763c352435f24",
    "url": "/projects/projects2018/--testing-temp--/static/js/runtime-main.ea78690d.js"
  },
  {
    "revision": "3292c2933620c051308eaba8c1a7eb22",
    "url": "/projects/projects2018/--testing-temp--/static/media/1.3292c293.png"
  },
  {
    "revision": "68d0c94108b474d54aba4f7626a225c4",
    "url": "/projects/projects2018/--testing-temp--/static/media/2.68d0c941.png"
  },
  {
    "revision": "9f539fb958848719b304d1a2cf11545d",
    "url": "/projects/projects2018/--testing-temp--/static/media/3.9f539fb9.png"
  },
  {
    "revision": "70f84118abef86de17c23a38931d2aac",
    "url": "/projects/projects2018/--testing-temp--/static/media/4.70f84118.png"
  },
  {
    "revision": "d3b507095b33ede18638f1d704ed0832",
    "url": "/projects/projects2018/--testing-temp--/static/media/abcde.d3b50709.png"
  },
  {
    "revision": "e44189e7882ec25d93acb8b03682f671",
    "url": "/projects/projects2018/--testing-temp--/static/media/ads.e44189e7.png"
  },
  {
    "revision": "0f2e1551cce75d83e7b89178793a367e",
    "url": "/projects/projects2018/--testing-temp--/static/media/background-pattern.0f2e1551.png"
  },
  {
    "revision": "3016481ff73db754b058a832e6821eca",
    "url": "/projects/projects2018/--testing-temp--/static/media/cpp-min.3016481f.png"
  },
  {
    "revision": "307b61e4d9e5bd970acbed844f4f92b1",
    "url": "/projects/projects2018/--testing-temp--/static/media/logo.307b61e4.png"
  },
  {
    "revision": "c9c6401bbe422458ea752da24c5837d1",
    "url": "/projects/projects2018/--testing-temp--/static/media/me-one.c9c6401b.jpg"
  },
  {
    "revision": "fdd872c470aa8d983d871b16b293f115",
    "url": "/projects/projects2018/--testing-temp--/static/media/me-two.fdd872c4.jpg"
  },
  {
    "revision": "a676f556e1207b91cd310ab0dbce26da",
    "url": "/projects/projects2018/--testing-temp--/static/media/projectloadingspinner.a676f556.svg"
  },
  {
    "revision": "62f7b414e071456c41088bf81c5eba92",
    "url": "/projects/projects2018/--testing-temp--/static/media/selfie-min.62f7b414.png"
  },
  {
    "revision": "d3b507095b33ede18638f1d704ed0832",
    "url": "/projects/projects2018/--testing-temp--/static/media/simple-to-do-list-mobile.d3b50709.png"
  },
  {
    "revision": "00ae39dddf15844e886b42783856ac6b",
    "url": "/projects/projects2018/--testing-temp--/static/media/simple-to-do-list-ss-desktop-one.00ae39dd.png"
  },
  {
    "revision": "d0b9c78c439f765ce4bdfc58104c084d",
    "url": "/projects/projects2018/--testing-temp--/static/media/simple-to-do-list-ss-desktop-one.d0b9c78c.png"
  },
  {
    "revision": "98d1605a7a72b9f2b81b3e6449dab611",
    "url": "/projects/projects2018/--testing-temp--/static/media/simple-to-do-list-ss-desktop-two.98d1605a.png"
  },
  {
    "revision": "d873345855f14daa2a4c4761103fee1e",
    "url": "/projects/projects2018/--testing-temp--/static/media/simple-to-do-list-ss-desktop-two.d8733458.png"
  },
  {
    "revision": "4cfbaa33f1cd3668813d5a9d3f1bec69",
    "url": "/projects/projects2018/--testing-temp--/static/media/simple-to-do-list-tablet.4cfbaa33.png"
  },
  {
    "revision": "7a0617b400b95c176aa1bdf08f43134e",
    "url": "/projects/projects2018/--testing-temp--/static/media/sorry-bubble.7a0617b4.png"
  },
  {
    "revision": "6b2630d1c69493f4abac46def20b2bc2",
    "url": "/projects/projects2018/--testing-temp--/static/media/under-construction.6b2630d1.png"
  },
  {
    "revision": "afbf846c4395ea195d117bbafdbe97f5",
    "url": "/projects/projects2018/--testing-temp--/static/media/website-login-mobile.afbf846c.png"
  },
  {
    "revision": "24c50efccd0f34c102de72544831c764",
    "url": "/projects/projects2018/--testing-temp--/static/media/website-login-ss-desktop-one.24c50efc.png"
  },
  {
    "revision": "93f48d6bcb8bf230e474cd7e5f354258",
    "url": "/projects/projects2018/--testing-temp--/static/media/website-login-ss-desktop-two.93f48d6b.png"
  },
  {
    "revision": "4a26c179e5162331884e7dc62e2594c8",
    "url": "/projects/projects2018/--testing-temp--/static/media/website-login-tablet.4a26c179.png"
  },
  {
    "revision": "7c43bcdffbe7ed0d8aa77915c2bddf65",
    "url": "/projects/projects2018/--testing-temp--/static/media/world-animal-protection-desktop-two.7c43bcdf.png"
  },
  {
    "revision": "86814f2c7ba8fbda5cdd6f182f5fb0bc",
    "url": "/projects/projects2018/--testing-temp--/static/media/world-animal-protection-desktop-two.86814f2c.png"
  },
  {
    "revision": "7c43bcdffbe7ed0d8aa77915c2bddf65",
    "url": "/projects/projects2018/--testing-temp--/static/media/world-animal-protection-desktop.7c43bcdf.png"
  },
  {
    "revision": "86814f2c7ba8fbda5cdd6f182f5fb0bc",
    "url": "/projects/projects2018/--testing-temp--/static/media/world-animal-protection-desktop.86814f2c.png"
  },
  {
    "revision": "91349bfd4a0176e93576b5f3941fecba",
    "url": "/projects/projects2018/--testing-temp--/static/media/world-animal-protection-mobile.91349bfd.png"
  },
  {
    "revision": "d36cdd108ccf59ba4d652d44434ec38b",
    "url": "/projects/projects2018/--testing-temp--/static/media/world-animal-protection-tablet.d36cdd10.png"
  }
]);